package com.hcl.hclassessment2.Service;

import com.hcl.hclassessment2.Entity.Product;
import com.hcl.hclassessment2.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repository;

    public Product addProduct(Product product) {
        return repository.save(product);
    }

    public List<Product> getAllProducts() {
        return repository.findAll();
    }

    public Product getProductById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product Not Found"));
    }

    public Product updateProduct(Long id, Product product) {

        Product existing = getProductById(id);

        existing.setProductName(product.getProductName());
        existing.setDescription(product.getDescription());
        existing.setPrice(product.getPrice());
        existing.setQuantity(product.getQuantity());
        existing.setCategory(product.getCategory());

        return repository.save(existing);
    }

    public String deleteProduct(Long id) {
        repository.deleteById(id);
        return "Product Deleted Successfully";
    }

    public List<Product> getByCategory(String category) {
        return repository.findByCategory(category);
    }

    public List<Product> searchByName(String name) {
        return repository.findByProductNameContainingIgnoreCase(name);
    }
}
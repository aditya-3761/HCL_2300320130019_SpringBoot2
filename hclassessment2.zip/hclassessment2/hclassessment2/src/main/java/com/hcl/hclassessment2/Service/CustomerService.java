package com.hcl.hclassessment2.Service;

import com.hcl.hclassessment2.Entity.Customer;
import com.hcl.hclassessment2.Repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repository;

    public Customer registerCustomer(Customer customer) {

        if(repository.findByEmail(customer.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        return repository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public Customer getCustomerById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    public Customer updateCustomer(Long id, Customer customer) {

        Customer existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        existing.setCustomerName(customer.getCustomerName());
        existing.setEmail(customer.getEmail());
        existing.setPassword(customer.getPassword());
        existing.setMobile(customer.getMobile());
        existing.setCity(customer.getCity());

        return repository.save(existing);
    }

    public String deleteCustomer(Long id) {

        repository.deleteById(id);

        return "Customer Deleted Successfully";
    }
}
package com.hcl.hclassessment2.Entity;

import jakarta.persistence.*;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Entity
public class Cart {

 @Setter
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long cartId;

 @Setter
 @OneToOne
 @JoinColumn(name = "customer_id")
 private Customer customer;

 private LocalDate createdDate;

 @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL)
 private List<com.hcl.hclassessment2.Entity.CartItem> cartItems;

 public Cart() {
 }

 public Long getCartId() {
  return cartId;
 }

    public Customer getCustomer() {
  return customer;
 }

    public LocalDate getCreatedDate() {
  return createdDate;
 }

 public void setCreatedDate(LocalDate createdDate) {
  this.createdDate = createdDate;
 }

 public List<CartItem> getCartItems() {
  return cartItems;
 }

 public void setCartItems(List<CartItem> cartItems) {
  this.cartItems = cartItems;
 }
}
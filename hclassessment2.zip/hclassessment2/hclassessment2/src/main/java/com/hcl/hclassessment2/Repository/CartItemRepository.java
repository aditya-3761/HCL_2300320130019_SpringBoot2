package com.hcl.hclassessment2.Repository;

public interface CartItemRepository {
}

package com.hcl.hclassessment2.Entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderItemId;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private com.hcl.hclassessment2.Entity.CustomerOrder customerOrder;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private com.hcl.hclassessment2.Entity.Product product;

    private Integer quantity;

    private BigDecimal price;

    public OrderItem() {
    }

    // Getters and Setters
}

package com.hcl.hclassessment2.Repository;

import com.hcl.hclassessment2.Entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByCategory(String category);

    List<Product> findByProductNameContainingIgnoreCase(String productName);
}
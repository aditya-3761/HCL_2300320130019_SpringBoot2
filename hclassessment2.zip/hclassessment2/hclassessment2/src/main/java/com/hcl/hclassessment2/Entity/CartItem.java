package com.hcl.hclassessment2.Entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartItemId;

    @ManyToOne
    @JoinColumn(name = "cart_id")
    private Cart cart;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private com.hcl.hclassessment2.Entity.Product product;

    private Integer quantity;

    private BigDecimal price;

    public CartItem() {
    }

    // Getters and Setters
}